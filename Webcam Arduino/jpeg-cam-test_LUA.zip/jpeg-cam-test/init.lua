wifi.setmode(wifi.SOFTAP)
cfg={}
cfg.ssid="mywifi"
cfg.pwd="qwerty123"
cfg.ip="192.168.0.1"
cfg.netmask="255.255.255.0"
cfg.gateway="192.168.0.1"
port=9876
wifi.ap.setip(cfg)
wifi.ap.config(cfg)

function stS(a,b)
  return string.sub(a,1,string.len(b))==b
end

function fhex(str)
  return (str:gsub('..', function(cc)
    return string.char(tonumber(cc,16))
  end))
end

function tohex(str)
  return (str:gsub('.',function(c)
    return string.format('%02X',string.byte(c))
  end))
end

function ith(a) return string.format('%06X',a) end
function nth() end
onSent=nth

function ascii(s,i) return string.byte(string.sub(s,i,i)) end

function getImg()
  bk = 240
  if bk>isz then bk=isz end
  uart.write(0,fhex("5600320C000A00"..ith(addr).."00"..ith(bk).."000A"))
  addr=addr+bk
  isz=isz-bk
  uart.on("data",bk+10,function(data)
    if isz==0 then
      onSent=nth
      uart.on("data")
    else
      onSent=getImg
    end
    send(string.sub(data,6,-6))
  end,0)   
end

function exe(st)
  rsp=5
  if stS(st,"56002600") then rsp=12 end
  if stS(st,"5600340100") then rsp=9 end
  if stS(st,"5600320C00") then
    addr=0
    onSent = getImg
    send("img "..isz.."\n")
    return
  end
  uart.write(0,fhex(st))
  uart.on("data",rsp,function(s)
    st=tohex(s).."\n"
    if(rsp==9) then
      isz=ascii(s,7)
      isz=bit.lshift(isz,8)+ascii(s,8)
      isz=bit.lshift(isz,8)+ascii(s,9)
      st=st.."size="..isz.."\n"
    end
    send(st)
    uart.on("data")
  end,0)
end

cmd=""
function rcvDat(c,data)
  cmd = cmd..data
  local a,b=string.find(cmd,"\n",1,true)
  while a do
    exe( string.sub(cmd,1,a-1))
    cmd=string.sub(cmd,a+1,string.len(cmd))
    a,b=string.find(cmd,"\n",1,true)
  end
end

print(":)")
srv=net.createServer(net.TCP,28800) 
srv:listen(port,function(conn)
  uart.setup(0,115200,8,0,1,1)
  function send(data) conn:send(data, onSent) end
  conn:on("receive",rcvDat) 
  conn:on("disconnection",function(c) uart.setup(0,9600,8,0,1,1) end)
end)

